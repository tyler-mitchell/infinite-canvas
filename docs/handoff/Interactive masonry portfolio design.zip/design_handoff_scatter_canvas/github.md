repo: tyler-mitchell/liveline
branch: main
path: src/math

## Last sync

date: 2026-09-09T14:52:00Z

### Updated in this project

- Read `src/math/spline.ts`, `lerp.ts`, `momentum.ts`, `range.ts` for the motion math behind the animated line chart.
- Ported Fritsch–Carlson monotone spline drawing into the `p95 latency` card's chart (no overshoot past local min/max).
- Ported the frame-rate-independent exponential lerp (`speed` per 16.67ms) for the Y-range camera.
- Ported `computeRange`'s 0.12 margin factor and `minRange` floor, and `detectMomentum`'s tail-vs-12%-of-range test, which now triggers the peak shake on swing onset only.

## Screen map

| Screen / widget | Built from |
| --- | --- |
| `Scatter Canvas.dc.html` → `p95 latency` card (travelling-camera chart) | `src/math/spline.ts`, `src/math/lerp.ts`, `src/math/range.ts`, `src/math/momentum.ts`, `README.md` |
| `Scatter Canvas.dc.html` → `infinite-canvas` repo card (replay-sweep chart) | own implementation; motion vocabulary informed by `README.md` (`degen` shake, `pulse`, badge) |

Note: nothing is copied as source — this project is a bundler-less browser environment, so the
algorithms were reimplemented inline in the Design Component. Liveline itself is MIT and
installable (`pnpm add liveline`) for the real portfolio build.
