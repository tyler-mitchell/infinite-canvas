# Handoff: Scatter Canvas

## The northstar

**A portfolio that behaves like a place, not a page.**

The thesis: a portfolio is usually a document about someone's work. This one is a *workspace* — the same spatial vocabulary the work itself is about. You don't scroll it, you inhabit it. Widgets are arranged on an unbounded plane, they can be dragged, expanded, unfolded, filtered, rained on. The medium *is* the argument: someone who builds spatial interfaces should hand you one, not a PDF about one.

Two consequences worth holding onto:

**Every widget is an instrument, not a card.** A card displays a value. An instrument reveals *behaviour* — it responds, it has state, it tells you something is running. A repo isn't a tile with a star count; it's a thing that unfolds into its own sub-board. A résumé isn't a link; it's a machine that prints one. The test for any new widget: *if it were static, would it still be worth its space?* If yes, it's a card and it probably shouldn't be here.

**The interface should reward attention without demanding it.** Nothing blocks, nothing autoplays, nothing begs. But everything holds up when you lean in: the rim light phases differently on tiles than cards, the storm dries out, the contribution grid reads as a life rather than noise, the receipt has a feed margin before its tear. A visitor who spends ten seconds gets a clean board. One who spends five minutes finds it was built by someone who cares about the parts nobody names.

## Philosophies

**Diegetic before decorative.** Every visual affordance should have an in-world reason. The dark region under the printer isn't a design choice — it's the machine's catch tray. The receipt isn't styled like a receipt; it *is* a receipt, for the résumé PDF, with an order number. When something feels off, the usual cause is that a part has no story: it's a shape doing nothing. That's the question to ask, not "what color should this be".

**Subtraction first.** The identity card felt wrong for four rounds. It didn't need better styling — it needed to stop carrying the board's navigation. Moved the filter chips into their own widget, cut the card by half, done. Same on the receipt: deleting subtotal/tax/card-number made the joke (`TOTAL PAID 0.00`) land harder. When something isn't working, try removing before adding.

**Fix at the constraint, not the pixel.** Every layout defect in this build had a structural cause one level up: a flex gap, a clipping ancestor, a row count derived from the wrong thing, a missing registry entry. Nudging the pixel always reintroduced the bug two turns later. When something is 8px off, find what *decides* that 8px.

**Restraint is the aesthetic.** Two typefaces, one accent color, one background family, hairlines instead of borders. Mono type is used for metadata *because it is metadata* — never because it looks technical. No gradient backgrounds, no filled chips shouting for attention, no emoji. The accent (mint) does exactly two jobs: status and the active state. If it starts appearing anywhere else, the palette is drifting.

**Motion carries meaning or it doesn't exist.** The paper feed is slow off the mark and long to settle because that's what a driven motor does. The rim sweep phases differently on tiles than on cards so the two read as different materials. Beams drift on incommensurate periods so the composition never repeats. Motion that just says "something animated here" is noise — cut it.

**Build for the person who inspects it.** This is a portfolio for an interface engineer; the audience will open devtools. Semantic DOM over canvas wherever text is involved, real keyboard paths on every interaction, ARIA live regions on status. The contribution grid is 371 focusable cells with one delegated listener, not a texture — partly because it's better UX, partly because someone *will* check.

---

## The design files

`Scatter Canvas.dc.html` and `Identity Variants.dc.html` are **design references written as browser-native HTML** — prototypes of intended look and behaviour, not production code. This environment has no bundler and no npm, so every algorithm is reimplemented inline just to run. Recreate the designs on **`@hyphened/infinite-canvas`** using its real primitives (`InfiniteCanvasWindow`, `renderFrame`, the snap resolver, groups, the scene layer, Legend State stores).

Where the prototype hand-rolls something the framework owns, **use the framework's** — the local copy exists only because it couldn't import yours.

| Prototype (inline) | Framework |
|---|---|
| `detailLevel(rect, zoom, prev)` | `getInfiniteCanvasWindowDetailLevel` — `detail-level.ts` |
| `spoke(i, n)` / `clampToViewport` | `hud/radial-geometry.ts` |
| connector path + label anchor | `connector-geometry.ts` |
| offscreen chevrons | `offscreen.ts` |
| `packItems(items, cols)` | your layout/packing module |
| `toBoard()` zoom conversion | canonical camera transform |
| spline / lerp / range / momentum | `liveline` — `pnpm add liveline` |

**Fidelity: high.** Colors, type, timings and easings are final and measured — recreate them faithfully. Structure and hierarchy are the parts worth *re-deciding* in your own primitives.

---

## Nine things I learned the hard way

Ordered by how much pain they save. These are conclusions from building it, not restatements of the design.

**1. Never trust `getBoundingClientRect` for "does it fit."** It returns the unclipped layout box — an element inside `overflow: hidden` reports full height while rendering cut off. I reported "19px of spacing" on a receipt that was visibly clipped, twice. Measure against the clipping ancestor, or check `scrollHeight - clientHeight` on the clipper.

**2. Derive expanded sizes from content, never from a row count.** Cell size is `(width - gaps) / cols`, so **row height scales with board width**. A literal `expandedRows: 5` fits at 1280px and clips at 900px. Compute rows from measured content. This one bug produced four rounds of "still clipping" that I couldn't reproduce, because my viewport differed from the user's.

**3. Continuous motion belongs on the compositor.** A per-frame `style.transform` loop looked like 25fps in a throttled host; the same motion as one CSS transition is butter. **JS owns state transitions; CSS owns the tween.** Paint per-frame only what can't be a tween — particles, canvas, physics.

**4. Assert structural invariants, not pixels.** Three bugs were caught by one cheap check and would otherwise have shipped:
```ts
board.children.length === authoredWidgets.length     // a missing registry entry renders unpositioned at 0,0
board.children.every(c => c.style.transform)         // everything got a layout pass
!widgets.some(w => widgets.some(o => o !== w && w.contains(o)))
clippedWidgets === 0
```
The missing-entry case is invisible in a screenshot — it renders at the origin under another widget and looks like a z-index bug.

**5. Substep any spring whose `dt` you don't control.** At a ~95ms fallback tick, explicit damping diverges to float-max. Fixed 16ms substeps. Nested sub-boards silently exploded before this.

**6. One conversion boundary for pointer↔board space.** Client px ≠ board px once the canvas is scaled. Drag tracked at 43% of cursor speed until every path crossed exactly one `toBoard()`.

**7. A zero-height flex child still costs you its gap.** A collapsed child left a 12px band that pushed a closed widget past its own box and put dead space between a dispenser and the paper that should have touched it. If a child can collapse to zero, take it out of flow.

**8. Zero-probability first, magnitude second, for synthetic data.** `rand() * scale` looks like static. Real activity is bimodal: decide *whether* a day is zero (11% weekday, 46% weekend, 92% on vacation), then how big. That one change took the contribution grid from noise to something that reads as a life.

**9. Hysteresis on every zoom-driven swap, and keep both trees mounted.** Demote below 120px, restore above 160px, on the smaller on-screen axis. Cross-fade rather than swap — swapping loses caret/scroll/focus and costs a layout exactly while the camera is moving.

---

## The widgets

45 total, first-fit packed, filterable by category (`about · work · signal · skill · writing`). The ones with ideas in them:

**Contribution calendar** — build this first; it's the most reusable and has no framework coupling. DOM cells, not canvas: 371 focusable days, one delegated listener. Correct calendar geometry (ISO weeks, current week last, head padded to Sunday, month labels where months actually start). The key UX call: **week count is fitted to available width at a legible cell size** — drop history before shrinking cells, because a 4px cell nobody can hit is worse than six honest months. One focus stop, arrows move by day/week.

**Receipt printer** — the diegetic centrepiece. The hierarchy is the whole thing: **widget = container, printer = a device inside it, lower area = the catch tray.** Getting that wrong makes it read as paper pasted on a card. Sheet is narrower than the dispenser slot it feeds through; feed is one smooth 1.75s tween with a 2px sliver left proud so the machine reads as loaded; toothed tear edge with a blank feed margin above it. The receipt is a *receipt for the résumé PDF* — order number, barcode, download action printed on the paper itself. Closing and reopening reprints.

**Inbox deck** — four stacked cards. Swiping right doesn't dismiss; it **converts the card into a widget on the board**, previewing the destination slot past the commitment threshold. That conversion is the interaction worth keeping.

**Repo cards / nested boards** — unfold into real sub-boards using the *same* packer at every depth, children springing outward from the parent's centre with a stagger. Recursion is the point: one layout function, any depth.

**Latency line** — a travelling-camera chart on Liveline's math. Add a **`flatline` prop**: it eases every sample toward the head's current level so the trace collapses to flat while the camera keeps travelling, then eases back out. Covers reconnects, tab-switches, empty states and source changes with no jarring cut. (Two things I got wrong before reading your source: `computeRange` needs the `minRange` floor or a quiet stretch collapses to a zero-height scale; `detectMomentum` is a *swing* detector — tail vs 12% of a 20-point lookback — not a slope detector. Fire reactions on the transition into a state, not every step.)

**Weather layer** — one canvas above the board reading live widget rects: rain, per-card wetness, crest highlights, bead run-off. Drops **retire rather than recycle** once intensity is spent, so the storm actually ends. In production this is a scene-layer pass over real window rects.

**Light field** — two blurred beams on incommensurate periods so the composition never repeats, with grain in `overlay` above the gradient. That grain is what kills banding on dark backgrounds.

**Identity** — four alternative directions are built out in `Identity Variants.dc.html` (kinetic wordmark, terminal session, letterpress calling card, atmosphere). Unresolved: pick one, or blend — atmosphere behind an instrument readout works well. Note the shipped one uses a monogram, not a photo: the fillable image empty state needs ~110px, so the photo belongs in its own widget.

**Sound** (`sound.js`) — dry and synthetic to match the substrate; no reverb, nothing naturalistic. What keeps it from sounding cheap: every blip is a 2ms noise tick + tuned body (a beep without a transient sounds *late*); bodies fall 20–40 cents over their decay; space is a 7ms Haas copy instead of a tail; the frequency budget is assigned so density stays legible; impacts draw from a refilling rate budget rather than a hard cap — that alone is most of what separates rain from static. Behind a persisted opt-in.

---

## Tokens

```
Board bg        #08090a
Widget card     #0c0d0f  ·  #0e0f11
Hairline        #1f2124  → hover #31343a      Inner  #16181a · #1c2026
Inner face      linear-gradient(180deg, #111318, #0b0c0e)
Recess          #040505                        Tray   #08090a
Text            #fff · #ededed · #c9cdd2 · #9aa0a6 · #878c92 · #7d8288
Accent          color(display-p3 0 0.92 0.67)  on-accent #04110b   dim #8ee9c4
Receipt         paper #faf9f5→#efece4 · ink #2b2b28 · label #6b6b66 · rule #c3c0b7
```
**`#7d8288` / `#878c92` are the dimmest values that clear 4.5:1** on the dark grounds; `#6b6b66` is the floor on receipt paper. I regressed below this three times — worth a lint rule.

**Type** — `Schibsted Grotesk` for UI and prose, `DM Mono` for metadata only. Labels 500 11px/1 0.02em · titles 600 17px/1.15 -0.03em · body 400 11–12.5px/1.5 · metadata 400 10.5–11px/1.4.

**Radii** 20 widget · 14 inner card · 12 tray · 7 chip · 4 aperture.
**Shadows** `inset 0 1px 0 rgba(255,255,255,0.04)` · `0 22px 60px -42px rgba(0,0,0,0.9)` · tray `inset 0 3px 10px rgba(0,0,0,0.7)`.
**Grid** cols 16/13/10/8/6 at ≥1120/880/660/470/<470, gap 12, cell `(w − gaps) / cols`.
**Motion** paper `1.75s cubic-bezier(0.77,0,0.175,1)` · expand spring substepped 16ms · detail cross-fade ~110ms · hover `160ms cubic-bezier(0.32,0.72,0,1)` · rim sweep `5.5s linear`.

**Assets** — no bitmaps. Tech logos from `cdn.simpleicons.org` tinted `8b8f94`; `image-slot.js` marks user-fillable photo areas; fonts from Google Fonts.

## Files

`Scatter Canvas.dc.html` (board, widgets, weather, packer) · `Identity Variants.dc.html` · `sound.js` · `blob-fx.js` · `image-slot.js` · `github.md` (Liveline sync record + screen map)

## Suggested order

Calendar → identity + filter strip → repo cards on real windows with semantic zoom → nested sub-boards via group layout → printer → scene layer → sound.

Start with the calendar because it ships alone and proves the shell vocabulary. Leave the scene layer late — it's the most fun and the least load-bearing.
