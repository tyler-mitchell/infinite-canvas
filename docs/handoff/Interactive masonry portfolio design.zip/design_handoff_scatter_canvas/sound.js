/**
 * Scatter Canvas — sound.
 *
 * Fitted to the substrate: this interface is dry, taut and hairline-precise, so
 * the sound is too. No room, no convolution, no naturalistic foley. Synthetic
 * ticks and blips — but the finesse is in the parts nobody names:
 *
 * 1. TRANSIENT + BODY. Even a 30ms blip is two things: a 2ms noise tick that
 *    gives the ear an attack to latch onto, and a tuned body under it. Without
 *    the tick a beep sounds soft and late; without the body it sounds cheap.
 * 2. PITCH MICRO-ENVELOPES. Every body drops 20–40 cents over its decay. Static
 *    pitch reads as a test tone; a falling tail reads as a physical event. It is
 *    a few cents, deliberately below conscious detection.
 * 3. NO REVERB, BUT NOT MONO. Space comes from a 7ms Haas copy panned opposite
 *    at −13dB: width without a tail, so nothing blurs the interface's edges.
 * 4. FREQUENCY BUDGET. Rain texture 2–7kHz, drop bodies 1.4–3.2k, UI 300–1800Hz,
 *    onset sub 45–60Hz. Nothing overlaps, so density stays legible.
 * 5. ONE SCALE. D minor pentatonic, every hit detuned a few cents, so repeated
 *    events consonate but never sound sampled.
 * 6. RATE BUDGET, NOT A CAP. Impacts draw from a refilling budget: bursts are
 *    allowed, sustained machine-gunning is not. That single rule is most of what
 *    separates rain from static.
 * 7. DUCKING, NOT VOLUME. UI events sidechain the texture bed down 20–50% for
 *    90ms so they cut through by making room.
 * 8. EVERY parameter move is a ramp. A direct assignment is a click.
 */
(function () {
  var A = { on: false, ready: false };
  var ctx, master, comp, limiter, tilt, wide, widePan;
  var noise, bed, bedBody, bedAir, bedGain, airGain, sub, subGain;
  var voices = 0, lastTick = 0, budget = 4;
  var R = 146.83;                       /* D3 */
  var SCALE = [1, 1.1225, 1.3348, 1.4983, 1.7818, 2];

  function noiseBuffer(sec) {
    var n = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  function init() {
    if (A.ready) return;
    var C = window.AudioContext || window.webkitAudioContext;
    if (!C) return;
    ctx = new C();
    A.ctx = ctx;

    limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -1.2; limiter.knee.value = 0; limiter.ratio.value = 20;
    limiter.attack.value = 0.002; limiter.release.value = 0.08;
    limiter.connect(ctx.destination);

    comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -22; comp.knee.value = 24; comp.ratio.value = 2.4;
    comp.attack.value = 0.006; comp.release.value = 0.18;
    comp.connect(limiter);

    tilt = ctx.createBiquadFilter();
    tilt.type = 'highshelf'; tilt.frequency.value = 6000; tilt.gain.value = 1.2;
    tilt.connect(comp);

    master = ctx.createGain();
    master.gain.value = 0;
    master.connect(tilt);

    /* width instead of depth: a single early copy, opposite channel, no tail */
    wide = ctx.createDelay(0.05);
    wide.delayTime.value = 0.007;
    var wg = ctx.createGain(); wg.gain.value = 0.22;
    widePan = ctx.createStereoPanner(); widePan.pan.value = 0.55;
    master.connect(wide); wide.connect(wg); wg.connect(widePan); widePan.connect(tilt);

    noise = noiseBuffer(3);

    /* texture bed: not a field recording — a narrow band of filtered noise that
       reads as fine particulate motion. Quiet enough to notice only when it stops. */
    bed = ctx.createBufferSource();
    bed.buffer = noise; bed.loop = true;

    bedBody = ctx.createBiquadFilter();
    bedBody.type = 'bandpass'; bedBody.frequency.value = 2400; bedBody.Q.value = 1.1;
    bedAir = ctx.createBiquadFilter();
    bedAir.type = 'bandpass'; bedAir.frequency.value = 6200; bedAir.Q.value = 0.8;

    bedGain = ctx.createGain(); bedGain.gain.value = 0;
    airGain = ctx.createGain(); airGain.gain.value = 0;

    bed.connect(bedBody); bedBody.connect(bedGain); bedGain.connect(master);
    bed.connect(bedAir); bedAir.connect(airGain); airGain.connect(master);

    sub = ctx.createOscillator();
    sub.type = 'sine'; sub.frequency.value = 52;
    subGain = ctx.createGain(); subGain.gain.value = 0;
    sub.connect(subGain); subGain.connect(master);

    bed.start(); sub.start();
    A.ready = true;
  }

  function enable() {
    init();
    if (!A.ready) return;
    if (ctx.state === 'suspended') ctx.resume();
    A.on = true;
    master.gain.cancelScheduledValues(ctx.currentTime);
    master.gain.setTargetAtTime(0.85, ctx.currentTime, 0.2);
  }

  function disable() {
    if (!A.ready) return;
    A.on = false;
    master.gain.setTargetAtTime(0, ctx.currentTime, 0.15);
  }

  function duck(amount, at) {
    if (!bedGain) return;
    var g = bedGain.gain.value;
    bedGain.gain.setTargetAtTime(g * (1 - amount), at, 0.015);
    bedGain.gain.setTargetAtTime(g, at + 0.09, 0.13);
  }

  /* 2ms filtered noise tick — the attack every synthetic sound needs */
  function tick(t, freq, peak, pan) {
    var src = ctx.createBufferSource();
    src.buffer = noise;
    src.playbackRate.value = 0.9 + Math.random() * 0.4;
    var hp = ctx.createBiquadFilter();
    hp.type = 'bandpass'; hp.frequency.value = freq; hp.Q.value = 1.2;
    var g = ctx.createGain();
    g.gain.setValueAtTime(peak, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.012);
    var p = ctx.createStereoPanner(); p.pan.value = pan || 0;
    src.connect(hp); hp.connect(g); g.connect(p); p.connect(master);
    src.start(t, Math.random() * 2, 0.02);
  }

  /* tuned body with a falling pitch tail */
  function blip(t, freq, dur, peak, type, pan, bend) {
    var o = ctx.createOscillator();
    o.type = type || 'triangle';
    var f = freq * (1 + (Math.random() - 0.5) * 0.004);
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(f * (bend === undefined ? 0.978 : bend), t + dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    var lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = Math.min(9000, freq * 5);
    var p = ctx.createStereoPanner(); p.pan.value = pan || 0;
    o.connect(lp); lp.connect(g); g.connect(p); p.connect(master);
    o.start(t); o.stop(t + dur + 0.04);
  }

  /* rain, read as texture rather than weather */
  function setRain(i, w) {
    if (!A.ready || !A.on) return;
    var t = ctx.currentTime;
    var g = Math.pow(Math.max(0, Math.min(1, i)), 0.9);
    bedGain.gain.setTargetAtTime(g * 0.085, t, 0.4);
    airGain.gain.setTargetAtTime(g * 0.04, t, 0.55);
    bedBody.frequency.setTargetAtTime(2100 + g * 900 + w * 120, t, 0.5);
    bedAir.frequency.setTargetAtTime(5400 + g * 2200, t, 0.7);
    subGain.gain.setTargetAtTime(i > 0.02 && i < 0.45 ? 0.03 : 0, t, 1.2);
  }

  /* one impact: tick + short high body, panned to where it landed */
  /* speed is the impact velocity in px/s; it sets level and brightness, so a
     fast near drop cracks and a slow far one taps. */
  function drop(x, z, wet, speed) {
    if (!A.ready || !A.on) return;
    var t = ctx.currentTime + 0.002;
    budget = Math.min(2, budget + (t - lastTick) * 3.2);
    lastTick = t;
    if (budget < 1 || voices > 3) return;
    budget -= 1;
    var near = z === 2 ? 1 : z === 1 ? 0.6 : 0.28;
    var pan = Math.max(-1, Math.min(1, (x / window.innerWidth) * 2 - 1)) * 0.75;
    var v = Math.max(0, Math.min(1, ((speed || 900) - 400) / 1100));
    var f = 1300 + v * 1500 + Math.random() * 500 + near * 220;
    var peak = (0.008 + v * 0.026) * near * (0.5 + wet * 0.5);
    tick(t, f * 1.6, peak * 0.35, pan);
    blip(t, f, 0.022 + Math.random() * 0.022, peak, 'sine', pan, 0.93);
    voices++;
    setTimeout(function () { voices--; }, 80);
  }

  /* run-off: two descending ticks, the sound of something leaving a surface */
  function bead(x) {
    if (!A.ready || !A.on) return;
    if (Math.random() > 0.35) return;
    var t = ctx.currentTime + 0.002;
    if (voices > 9) return;
    var pan = Math.max(-1, Math.min(1, (x / window.innerWidth) * 2 - 1)) * 0.65;
    blip(t, 980, 0.05, 0.03, 'sine', pan, 0.86);
    blip(t + 0.055, 660, 0.075, 0.022, 'sine', pan, 0.82);
    voices++;
    setTimeout(function () { voices--; }, 160);
  }

  /* ── motion ───────────────────────────────────────────────────────────────
     Layout has real velocity, so it can be heard directly: a low band of noise
     whose level tracks the board's kinetic energy. It swells as a reflow starts
     and dies as the springs settle — the sound is the physics, not a cue fired
     alongside it. */
  var mot, motBp, motGain, motOn = false;
  function motionInit() {
    if (motOn || !A.ready) return;
    mot = ctx.createBufferSource();
    mot.buffer = noise; mot.loop = true;
    motBp = ctx.createBiquadFilter();
    motBp.type = 'bandpass'; motBp.frequency.value = 320; motBp.Q.value = 1.6;
    motGain = ctx.createGain(); motGain.gain.value = 0;
    mot.connect(motBp); motBp.connect(motGain); motGain.connect(master);
    mot.start();
    motOn = true;
  }

  function setMotion(energy) {
    if (!A.ready || !A.on) return;
    motionInit();
    var t = ctx.currentTime;
    var e = Math.max(0, Math.min(1, energy));
    /* curved so small settling motion is nearly silent and a full reflow is present */
    motGain.gain.setTargetAtTime(Math.pow(e, 1.6) * 0.05, t, 0.05);
    motBp.frequency.setTargetAtTime(240 + e * 620, t, 0.08);
    motBp.Q.setTargetAtTime(1.4 + e * 2.2, t, 0.1);
  }

  /* a widget coming to rest. Pitch from its mass (area), level from the speed it
     arrived with — so a big card lands low and soft, a tile lands high and tight. */
  function land(x, area, speed) {
    if (!A.ready || !A.on) return;
    if (voices > 6) return;
    var t = ctx.currentTime + 0.003;
    var mass = Math.max(0.05, Math.min(1, area / 120000));
    var f = 900 - mass * 620;
    var v = Math.max(0, Math.min(1, (speed - 90) / 700));
    if (v <= 0.02) return;
    var pan = Math.max(-1, Math.min(1, (x / window.innerWidth) * 2 - 1)) * 0.5;
    tick(t, f * 3, 0.012 * v, pan);
    blip(t, f, 0.05 + mass * 0.09, 0.02 * v + 0.004, 'sine', pan, 0.94);
    voices++;
    setTimeout(function () { voices--; }, 180);
  }

  function ui(kind) {
    if (!A.ready || !A.on) return;
    var t = ctx.currentTime + 0.004;
    if (kind === 'press') {
      tick(t, 2600, 0.03, 0);
      blip(t, R * 4, 0.03, 0.022, 'triangle', 0, 0.96);
      duck(0.18, t);
    } else if (kind === 'unfold') {
      tick(t, 3200, 0.022, -0.2);
      blip(t, R * 2 * SCALE[1], 0.05, 0.032, 'triangle', -0.18, 0.99);
      blip(t + 0.052, R * 2 * SCALE[4], 0.07, 0.026, 'sine', 0.18, 0.99);
      duck(0.34, t);
    } else if (kind === 'fold') {
      blip(t, R * 2 * SCALE[4], 0.045, 0.024, 'sine', 0.18, 0.97);
      blip(t + 0.048, R * 2 * SCALE[1], 0.06, 0.028, 'triangle', -0.18, 0.95);
      duck(0.28, t);
    } else if (kind === 'focus') {
      /* the plane change: a tick, then a fifth that settles rather than swells */
      tick(t, 1800, 0.018, 0);
      blip(t, R * 2, 0.09, 0.03, 'sine', -0.12, 0.985);
      blip(t + 0.03, R * 3, 0.12, 0.02, 'sine', 0.12, 0.985);
      duck(0.42, t);
    } else if (kind === 'blur') {
      blip(t, R * 3, 0.08, 0.018, 'sine', 0.1, 0.97);
      blip(t + 0.026, R * 2, 0.1, 0.022, 'sine', -0.1, 0.96);
      duck(0.2, t);
    } else if (kind === 'decode') {
      /* data chirp: six 16ms grains up the scale, humanised spacing */
      for (var i = 0; i < 6; i++) {
        var f = R * 4 * SCALE[i % SCALE.length] * (i > 4 ? 2 : 1);
        blip(t + i * 0.038 + Math.random() * 0.008, f, 0.016, 0.014, 'square', (i % 2 ? 0.22 : -0.22), 1);
      }
      duck(0.24, t);
    } else if (kind === 'onset') {
      /* weather arriving: one low tick and a brief band of noise, no tail */
      var src = ctx.createBufferSource();
      src.buffer = noise;
      var lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(680, t);
      lp.frequency.exponentialRampToValueAtTime(180, t + 0.5);
      var g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.05, t + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
      src.connect(lp); lp.connect(g); g.connect(master);
      src.start(t, Math.random() * 2, 0.6);
      blip(t, 58, 0.3, 0.05, 'sine', 0, 0.8);
    } else if (kind === 'clear') {
      blip(t, R * 4 * SCALE[3], 0.06, 0.022, 'sine', 0, 1.01);
      blip(t + 0.06, R * 4 * SCALE[5], 0.09, 0.018, 'sine', 0, 1.01);
    }
  }

  A.enable = enable;
  A.disable = disable;
  A.toggle = function () { A.on ? disable() : enable(); return A.on; };
  A.setRain = setRain;
  A.setMotion = setMotion;
  A.land = land;
  A.drop = drop;
  A.bead = bead;
  A.ui = ui;
  A.isOn = function () { return A.on; };
  window.SC_AUDIO = A;
})();
