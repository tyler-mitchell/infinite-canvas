(function () {
  var VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
  var FS = [
    'precision highp float;',
    'uniform vec2 uRes;uniform float uT;uniform vec2 uM;',
    'float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}',
    'float map(vec3 q){',
    '  float t=uT*.45;',
    '  float d=length(q-vec3(sin(t)*.34,cos(t*.8)*.26,0.))-.62;',
    '  d=smin(d,length(q-vec3(cos(t*.7)*.4,sin(t*1.1)*.3,sin(t*.6)*.2))-.5,.42);',
    '  d=smin(d,length(q-vec3(sin(t*1.3)*.22,-.34+cos(t)*.2,cos(t*.9)*.25))-.44,.4);',
    '  return d;',
    '}',
    'vec3 nrm(vec3 q){vec2 e=vec2(.0015,0.);return normalize(vec3(map(q+e.xyy)-map(q-e.xyy),map(q+e.yxy)-map(q-e.yxy),map(q+e.yyx)-map(q-e.yyx)));}',
    'void main(){',
    '  vec2 uv=(gl_FragCoord.xy*2.-uRes)/min(uRes.x,uRes.y);',
    '  vec3 ro=vec3(uv*1.52+uM*.2,-3.2),rd=vec3(0.,0.,1.);',
    '  float t=0.;vec3 q;bool hit=false;',
    '  for(int i=0;i<64;i++){q=ro+rd*t;float d=map(q);if(d<.002){hit=true;break;}t+=d*.92;if(t>7.)break;}',
    '  if(!hit){gl_FragColor=vec4(0.);return;}',
    '  vec3 n=nrm(q);vec3 v=-rd;',
    '  float fres=pow(1.-max(dot(n,v),0.),3.4);',
    '  vec3 l1=normalize(vec3(-.5,.85,-.7)),l2=normalize(vec3(.75,-.3,-.6));',
    '  float k1=max(dot(n,l1),0.),k2=max(dot(n,l2),0.);',
    '  float s1=pow(max(dot(reflect(-l1,n),v),0.),90.),s2=pow(max(dot(reflect(-l2,n),v),0.),40.);',
    '  vec3 base=mix(vec3(.015,.075,.06),vec3(.055,.62,.47),k1*.95);',
    '  base+=vec3(.03,.24,.19)*k2;',
    '  base+=vec3(.55,1.,.86)*s1*.9+vec3(.2,.5,.45)*s2*.5;',
    '  base+=mix(vec3(.05,.5,.4),vec3(.55,.85,1.),.5+.5*sin(n.y*4.+uT*.6))*fres*.7;',
    '  gl_FragColor=vec4(base,clamp(.86+fres,0.,1.));',
    '}'
  ].join('\n');
  function boot(cv) {
    var g = cv.getContext('webgl', { alpha: true, premultipliedAlpha: false, antialias: true });
    if (!g) return;
    function sh(type, src) { var s = g.createShader(type); g.shaderSource(s, src); g.compileShader(s); return s; }
    var pr = g.createProgram();
    g.attachShader(pr, sh(g.VERTEX_SHADER, VS));
    g.attachShader(pr, sh(g.FRAGMENT_SHADER, FS));
    g.linkProgram(pr);
    if (!g.getProgramParameter(pr, g.LINK_STATUS)) { console.warn('blob link failed'); return; }
    g.useProgram(pr);
    var buf = g.createBuffer();
    g.bindBuffer(g.ARRAY_BUFFER, buf);
    g.bufferData(g.ARRAY_BUFFER, new Float32Array([-1,-1,3,-1,-1,3]), g.STATIC_DRAW);
    var loc = g.getAttribLocation(pr, 'p');
    g.enableVertexAttribArray(loc);
    g.vertexAttribPointer(loc, 2, g.FLOAT, false, 0, 0);
    var uRes = g.getUniformLocation(pr, 'uRes'), uT = g.getUniformLocation(pr, 'uT'), uM = g.getUniformLocation(pr, 'uM');
    var mx = 0, my = 0;
    window.addEventListener('pointermove', function (e) {
      var r = cv.getBoundingClientRect();
      mx = (e.clientX - (r.left + r.width / 2)) / Math.max(r.width, 1);
      my = -(e.clientY - (r.top + r.height / 2)) / Math.max(r.height, 1);
    }, { passive: true });
    function frame(ms) {
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var w = Math.round(cv.clientWidth * dpr), h = Math.round(cv.clientHeight * dpr);
      if (w && h && (cv.width !== w || cv.height !== h)) { cv.width = w; cv.height = h; }
      g.viewport(0, 0, cv.width, cv.height);
      g.uniform2f(uRes, cv.width, cv.height);
      var e = window.__scEnergy || 0;
      window.__scT = (window.__scT || 0) + 16 * (1 + e * 2.4);
      g.uniform1f(uT, ((ms || 0) + window.__scT * e) / 1000);
      g.uniform2f(uM, 0, 0);
      g.clearColor(0, 0, 0, 0);
      g.clear(g.COLOR_BUFFER_BIT);
      g.drawArrays(g.TRIANGLES, 0, 3);
      requestAnimationFrame(frame);
    }
    frame(1200);
    /* the preview pane never advances rAF, so paint one settled frame regardless */
    setTimeout(function () { frame(2400); }, 400);
  }
  var tries = 0;
  (function wait() {
    var cv = document.getElementById('blobfx');
    if (cv && cv.clientWidth) return boot(cv);
    if (tries++ < 200) setTimeout(wait, 60);
  })();
})();
